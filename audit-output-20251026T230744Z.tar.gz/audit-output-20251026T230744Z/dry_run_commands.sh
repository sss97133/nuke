#!/bin/bash
# Dry run commands - DO NOT EXECUTE without review
# Remove 'echo' to execute actual commands

echo "gh pr close 142 --repo sss97133/nuke"
echo "gh pr close 140 --repo sss97133/nuke"
echo "gh pr close 138 --repo sss97133/nuke"
echo "gh pr close 137 --repo sss97133/nuke"
echo "gh pr close 136 --repo sss97133/nuke"
echo "gh pr close 135 --repo sss97133/nuke"
echo "gh pr close 134 --repo sss97133/nuke"
echo "gh pr close 133 --repo sss97133/nuke"
echo "gh pr close 131 --repo sss97133/nuke"
